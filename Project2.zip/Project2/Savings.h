#ifndef SAVINGS_H_
#define SAVINGS_H_
#include <string>
using namespace std;

class Savings {
	public:
		double calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double interestRate, int numberOfYears);  // Calculate and print report without monthly deposits
		double balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears);  // Calculate and print report with monthly deposits
		void PrintDetails(int year, double yearEndBalance, double interestEarned);  // Called to print each line for every year in the reports

	private:
		double initialDeposit;
		double monthlyDeposit;
		double interestRate;
		int numYears;
};

#endif