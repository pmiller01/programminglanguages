#include <iomanip>
#include <iostream>
#include "Savings.h"
using namespace std;

// Function to print each row for every year in the reports
void Savings::PrintDetails(int year, double yearEndBalance, double interestEarned) {
	cout << right << setw(1) << year << fixed << setprecision(2) << setw(20) << yearEndBalance << setw(35) << interestEarned << endl;
}

// Function to print report without the monthly deposits
double Savings::calculateBalanceWithoutMonthlyDeposit(double initialInvestment, double interestRate, int numberOfYears) {
	int currentYear = 1;
	double yearEndBalance = initialInvestment;

	while (currentYear <= numberOfYears) {  // While loop to iterate through each year user inputted
		double interestEarned = yearEndBalance * (interestRate / 100);  // Calculate interest
		yearEndBalance += interestEarned;  // Add interest to previous year balance to get the final balance
		PrintDetails(currentYear, yearEndBalance, interestEarned);  // Call print details funciton
		currentYear += 1;  // Add year
	}
	return yearEndBalance;
	
}

double Savings::balanceWithMonthlyDeposit(double initialInvestment, double monthlyDeposit, double interestRate, int numberOfYears) {
	int currentYear = 1;
	double yearEndBalance = initialInvestment;

	while (currentYear <= numberOfYears) { // While loop to iterate through each year user inputted
		int month = 1;
		double interestEarned = 0.0;
		double monthEndBalance = yearEndBalance;

		while (month <= 12) {  // While loop to calculate the interest and end balance for each month
			monthEndBalance += monthlyDeposit;  // Calculate the balance for each month in each year
			double monthlyInterest = monthEndBalance * (interestRate / (100 * 12));  // Calculate the monthly interest amount
			interestEarned += monthlyInterest;  // Calculate overall year interest
			monthEndBalance += monthlyInterest;  // Add the interest for each month to the end balance
			month += 1;
		}

		yearEndBalance = monthEndBalance;  // Set year end balance to the total balance of each month for each year
		PrintDetails(currentYear, yearEndBalance, interestEarned);
		currentYear += 1;  // Add year
	}
	return yearEndBalance;
}


