#include <iostream>
#include <iomanip>
#include "Savings.h"
using namespace std;

int main() {
	double investment;
	double monthlyDeposit;
	double interestRate;
	int years;
	string choice;
	Savings mySavings;

	while (true) {
		// Output for blank menu to show user what they will input
		cout << "**************************************" << endl;
		cout << "************* Data Input *************" << endl;
		cout << "Initial Investment Amount: " << endl;
		cout << "Monthly Deposit: " << endl;
		cout << "Annual Interest: " << endl;
		cout << "Number of years: " << endl;
		cout << "Press any key to continue..." << endl;
		system("PAUSE");
		cout << endl;

		// Get input from user and add it to menu
		cout << "**************************************" << endl;
		cout << "************* Data Input *************" << endl;
		cout << "Initial Investment Amount: $";
		cin >> investment;  // User enters amount for initial investment
		cout << "Monthly Deposit: $";
		cin >> monthlyDeposit;  // User enters amount for how much money is deposited each month
		cout << "Annual Interest: %";
		cin >> interestRate;  // User enters amount for the interest rate
		cout << "Number of years: ";
		cin >> years;  // User enters the number of years they want to calculate for
		system("PAUSE");


		cout << endl;
		// Output header for report without monthly deposits
		cout << "  Balance and Interest without Additional Monthly Deposits " << endl;
		cout << "============================================================" << endl;
		cout << setw(10) << "Year" << setw(20) << "Year End Balance" << setw(35) << "Year End Earned Interest Rate" << endl;
		cout << "-------------------------------------------------------------" << endl;

		// Function call to calculate and print report without monthly deposits
		mySavings.calculateBalanceWithoutMonthlyDeposit(investment, interestRate, years);

		cout << endl;
		// Output header for report with monthly depsits
		cout << "  Balance and Interest with Additional Monthly Deposits " << endl;
		cout << "============================================================" << endl;
		cout << setw(5) << "Year" << setw(20) << "Year End Balance" << setw(35) << "Year End Earned Interest Rate" << endl;
		cout << "-------------------------------------------------------------" << endl;

		if (monthlyDeposit > 0) {  // If the user entered a monthly deposit amount greater than 0, then the report with monthly deposits will print
			mySavings.balanceWithMonthlyDeposit(investment, monthlyDeposit, interestRate, years);
		}

		cout << endl;
		cout << "Do you want to perform another calculation? (y/n):";  // Ask user if they want to perform another calculation
		cin >> choice;  // Get choice (y or n) from user
		if (choice != "y") {  // If the user does not enter "y" the program will end. Otherwise the user will be directed back to input another set of values
			break;
		}
		cout << endl;
	}
	return 0;
}
